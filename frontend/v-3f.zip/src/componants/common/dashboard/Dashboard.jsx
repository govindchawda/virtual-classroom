import React, { useEffect, useState } from 'react'
// import './Students.css';
import { HiOutlineDotsVertical } from "react-icons/hi";
import { FaBars } from "react-icons/fa";
import { BsChatRightTextFill } from "react-icons/bs";
import { BsFillPersonLinesFill } from "react-icons/bs";
import { MdAssignment } from "react-icons/md";
import { MdFeedback } from "react-icons/md";
import { CgLogOut } from "react-icons/cg";
import { CgProfile } from "react-icons/cg";
import { RiLockPasswordFill } from "react-icons/ri";
import { Link, Outlet, useLocation, useNavigate } from 'react-router-dom';
import axios from 'axios';
import { PiStudentBold } from "react-icons/pi";
import { GiTeacher } from "react-icons/gi";
import { MdManageHistory } from "react-icons/md";
import { MdOutlineManageSearch } from "react-icons/md";
import { FaUsers } from "react-icons/fa";

export default function Dashboard() {
    const [admins, setAdmin] = useState(false);
    const [teacher, setTeacher] = useState(false);
    const [student, setStudent] = useState(false);
    const [showSpanTag, setShowSpanTag] = useState(true);
    const [user, setUser] = useState([]);
    const navigate = useNavigate();

    // SHOW HIDE SPAN TAGS
    const hideSpanTag = () => {
        setShowSpanTag(showSpanTag == true ? false : true)
    };

    // LOGOUT
    const logout = () => {
        localStorage.removeItem("tokeId");
        navigate('/');
    }

    // GET SELF PROFILE
    useEffect(() => {
        axios.get('http://localhost:4000/api/auth/getusers', {
            headers: {
                "Authorization": "bearer " + localStorage.getItem("tokeId")
            }
        }).then((res) => {
            setUser(res.data.result);
            if (res.data.result.role === 'admin') {
                setAdmin(true)
            }
            else if (res.data.result.role === 'teacher') {
                setTeacher(true)
            }
            else if (res.data.result.role === 'student') {
                setStudent(true)
            }
            else {
                navigate('/')
            }
        }).catch((error) => {
            console.log(`user profile error : ${error}`)
        })
    }, []);

    return (
        <>
            <section className="dashboard">
                <div className='topbar'>
                    <div className='topbar-image'>
                        <div className='topbae-logo'>
                            <img src="https://i.ibb.co/0RdZZbhD/Screenshot-2025-05-30-162121.png" alt="" />
                            <FaBars onClick={hideSpanTag} className='bar_icons' />
                        </div>
                        <div className='user-topbarIcons dot_icons'>
                            <HiOutlineDotsVertical className='dot_icons' />
                            <div className='user-logout'>
                                <span> ! Welcome</span>
                                <li><Link to="profile"><img src={user.profile} alt="" />Profile</Link></li>
                                <li><a href="" onClick={logout}><CgLogOut /> Log out</a></li>
                            </div>
                        </div>
                    </div>
                </div>
                <div className='middlebar'>
                    {student === true &&
                        <div className='leftbar'>
                            <ul>
                                <li className='text-center'><a href="">{showSpanTag == true &&
                                    <span className='leftbar-profile'>
                                        <img src={user.profile} alt="" /> <br />
                                        <b>{user.name}</b>
                                    </span>
                                }</a></li>
                                <li><a href=""><BsChatRightTextFill />{showSpanTag == true && <span>Message </span>}</a></li>
                                <li><a href=""><BsFillPersonLinesFill />{showSpanTag == true && <span>Classes</span>}</a></li>
                                <li><a href=""><BsFillPersonLinesFill />{showSpanTag == true && <span>Online Class</span>}</a></li>
                                <li><a href=""><MdAssignment />{showSpanTag == true && <span>Send Assignment</span>}</a></li>
                                <li><a href=""><MdFeedback />{showSpanTag == true && <span>Send feedback</span>}</a></li>
                                <li><Link to="change-password"><RiLockPasswordFill />{showSpanTag == true && <span>Change Password</span>}</Link></li>
                            </ul>
                        </div>
                    }
                    {teacher === true &&
                        <div className='leftbar'>
                            <ul>
                                <li className='text-center'><a href="">{showSpanTag == true &&
                                    <span className='leftbar-profile'>
                                        <img src={user.profile} alt="" /> <br />
                                        <b>{user.name}</b>
                                    </span>
                                }</a></li>
                                <li><a href=""><BsChatRightTextFill />{showSpanTag == true && <span>Message </span>}</a></li>
                                <li><Link to="classes"><BsFillPersonLinesFill />{showSpanTag == true && <span>Classes</span>}</Link></li>
                                <li><a href=""><BsFillPersonLinesFill />{showSpanTag == true && <span>Online Class</span>}</a></li>
                                <li><a href=""><MdAssignment />{showSpanTag == true && <span>Send Assignment</span>}</a></li>
                                <li><a href=""><MdFeedback />{showSpanTag == true && <span>Send feedback</span>}</a></li>
                                <li><Link to="ShowStudens"><MdFeedback />{showSpanTag == true && <span>Students</span>}</Link></li>
                                <li><Link to="change-password"><RiLockPasswordFill />{showSpanTag == true && <span>Change Password</span>}</Link></li>
                            </ul>
                        </div>
                    }
                    {admins === true &&
                        <div className='leftbar'>
                            <ul className='showoptions'>
                                <li className='text-center'><a href="">{showSpanTag == true &&
                                    <span className='leftbar-profile'>
                                        <img src={user.profile} alt="" /> <br />
                                        <b>{user.name}</b>
                                    </span>
                                }</a></li>
                                <li><a href=""><BsChatRightTextFill />{showSpanTag == true && <span>Message </span>}</a></li>

                                <li className='showusers'><Link className='showusera'><BsFillPersonLinesFill />{showSpanTag == true && <span>Classes</span>}
                                    <div className='useroptions'>
                                        <li><Link to="classes"><MdManageHistory />{showSpanTag == true && <span>Manage Classes</span>}</Link></li>
                                        <li><Link to="searchClasses" ><MdOutlineManageSearch />{showSpanTag == true && <span>Search Classes</span>}</Link></li>
                                    </div>
                                </Link></li>
                                <li className='showusers'>
                                    <Link className='showusera'><FaUsers />{showSpanTag == true && <span>User</span>}
                                        <div className='useroptions'>
                                            <li><Link to="ShowTeachers"><GiTeacher />{showSpanTag == true && <span>Teachers</span>}</Link></li>
                                            <li><Link to="ShowStudens"><PiStudentBold />{showSpanTag == true && <span>Students</span>}</Link></li>
                                        </div>
                                    </Link>
                                </li>
                                <li><a href=""><BsFillPersonLinesFill />{showSpanTag == true && <span>Online Class</span>}</a></li>
                                <li><a href=""><MdAssignment />{showSpanTag == true && <span>Send Assignment</span>}</a></li>
                                <li><a href=""><MdFeedback />{showSpanTag == true && <span>Send feedback</span>}</a></li>
                                <li><Link to="change-password"><RiLockPasswordFill />{showSpanTag == true && <span>Change Password</span>}</Link></li>
                            </ul>
                        </div>
                    }
                    <div className='rightbar'>
                        <Outlet />
                    </div>
                </div>
            </section>
        </>
    )
}
