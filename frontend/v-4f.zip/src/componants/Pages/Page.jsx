import React from 'react'
import Banner from './banner/Banner'
import Features from './features/Features'

export default function Page() {
  return (
    <>
        <Banner/>
        {/* <Features/> */}
    </>
  )
}
