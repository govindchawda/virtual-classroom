const cloudniry = require("cloudinary").v2

cloudniry.config({
    cloud_name: "dmrxcu4vs",
    api_key: "633773865524368",
    api_secret: "I2CuquFz9AZ0pVsjL8JqHUKDDBU",
});

module.exports = cloudniry;